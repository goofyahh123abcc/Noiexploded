import { gameState } from './gameState.js';
import { updateSuspicionMeter } from './suspicion.js';

export function updatePopcornCounter() {
    const popcornCountElement = document.getElementById('popcorn-count');
    if (popcornCountElement) {
        popcornCountElement.textContent = `Popcorn: ${gameState.popcornCount}`;
    }
}

export function gameOver(message) {
    if (gameState.isGameOver) return; // Prevent multiple game over calls

    gameState.isGameOver = true;
    const gameOverScreen = document.getElementById('game-over');
    const gameOverMessage = document.getElementById('game-over-message');
    
    if (gameOverScreen) {
        gameOverScreen.classList.remove('hidden');
    }
    if (gameOverMessage) {
        gameOverMessage.textContent = message;
    }

    // Optionally, stop animations or other game processes here
    // For example, if there's a main animation loop handle, cancel it:
    // if (gameState.animationFrameId) {
    //     cancelAnimationFrame(gameState.animationFrameId);
    // }
}

export function updateUIAfterRestart() {
    gameState.popcornCount = 50; // Reset to initial value
    gameState.suspicionLevel = 0;
    gameState.isGameOver = false;
    gameState.isPoliceComing = false;

    updatePopcornCounter();
    updateSuspicionMeter(); // Reset suspicion meter display

    const gameOverScreen = document.getElementById('game-over');
    if (gameOverScreen) {
        gameOverScreen.classList.add('hidden');
    }

    const policeWarning = document.getElementById('police-warning');
    if (policeWarning) {
        policeWarning.classList.add('hidden');
    }
}