import { gameState } from './gameState.js';
import { triggerPolice } from './police.js';

export function updateSuspicionMeter() {
    const meterFill = document.querySelector('.meter-fill');
    meterFill.style.width = `${gameState.suspicionLevel}%`;
    
    // Color changes based on suspicion level
    if (gameState.suspicionLevel < 30) {
        meterFill.style.backgroundColor = '#4caf50'; // Green
    } else if (gameState.suspicionLevel < 70) {
        meterFill.style.backgroundColor = '#ff9800'; // Orange
    } else {
        meterFill.style.backgroundColor = '#f44336'; // Red
    }
}

export function increaseSuspicion(amount) {
    gameState.suspicionLevel += amount;
    if (gameState.suspicionLevel > 100) gameState.suspicionLevel = 100;
    
    updateSuspicionMeter();
    
    // Check if police should come
    if (gameState.suspicionLevel > 85 && !gameState.isPoliceComing && !gameState.isGameOver) {
        triggerPolice();
    }
}

export function decreaseSuspicion() {
    if (gameState.suspicionLevel > 0 && !gameState.isGameOver) {
        gameState.suspicionLevel -= 0.1;
        if (gameState.suspicionLevel < 0) gameState.suspicionLevel = 0;
        updateSuspicionMeter();
    }
}