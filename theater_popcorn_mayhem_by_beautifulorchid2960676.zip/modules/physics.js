import * as CANNON from 'cannon-es';

export function initPhysics() {
    // Setup physics world
    const world = new CANNON.World({
        gravity: new CANNON.Vec3(0, -9.82, 0),
    });

    // Materials
    world.physicsMaterial = new CANNON.Material('popcornMaterial');
    world.theatreMaterial = new CANNON.Material('theatreMaterial');

    // Contact material (for bounce)
    const popcornTheaterContactMaterial = new CANNON.ContactMaterial(
        world.physicsMaterial,
        world.theatreMaterial,
        {
            friction: 0.5,
            restitution: 0.3,
        }
    );
    world.addContactMaterial(popcornTheaterContactMaterial);
    
    return world;
}

