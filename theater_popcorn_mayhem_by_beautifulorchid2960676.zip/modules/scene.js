import * as THREE from 'three';
import * as CANNON from 'cannon-es';

export function initScene() {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x111111);
    return scene;
}

export function createTheaterLighting(scene) {
    // Add ambient lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 1.5);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1);
    mainLight.position.set(10, 10, 10);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 2048;
    mainLight.shadow.mapSize.height = 2048;
    scene.add(mainLight);
    
    // Dim side lights
    const leftLight = new THREE.PointLight(0xf0c050, 0.5);
    leftLight.position.set(-8, 5, -5);
    scene.add(leftLight);

    const rightLight = new THREE.PointLight(0xf0c050, 0.5);
    rightLight.position.set(8, 5, -5);
    scene.add(rightLight);

    // Screen light (simulating movie projection)
    const screenLight = new THREE.RectAreaLight(0x5090f0, 2, 20, 10);
    screenLight.position.set(0, 5, -15);
    screenLight.lookAt(0, 5, 0);
    scene.add(screenLight);
}

export function createTheater(scene, world) {
    // Floor
    const floorGeometry = new THREE.PlaneGeometry(30, 30);
    const floorMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x333333,
        roughness: 0.9
    });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.5;
    floor.receiveShadow = true;
    scene.add(floor);

    // Floor physics
    const floorShape = new CANNON.Plane();
    const floorBody = new CANNON.Body({
        mass: 0,
        material: world.theatreMaterial
    });
    floorBody.addShape(floorShape);
    floorBody.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
    world.addBody(floorBody);

    // Create walls, seats, etc.
    createWalls(scene, world);
    createTheaterSeats(scene, world);
}

function createWalls(scene, world) {
    const wallMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x663322,
        roughness: 0.8
    });

    // Back wall
    const backWall = new THREE.Mesh(
        new THREE.BoxGeometry(30, 10, 0.5),
        wallMaterial
    );
    backWall.position.set(0, 4, 15);
    scene.add(backWall);

    // Back wall physics
    const backWallShape = new CANNON.Box(new CANNON.Vec3(15, 5, 0.25));
    const backWallBody = new CANNON.Body({ mass: 0, material: world.theatreMaterial });
    backWallBody.addShape(backWallShape);
    backWallBody.position.set(0, 4, 15);
    world.addBody(backWallBody);

    // Side walls
    const leftWall = new THREE.Mesh(
        new THREE.BoxGeometry(0.5, 10, 30),
        wallMaterial
    );
    leftWall.position.set(-15, 4, 0);
    scene.add(leftWall);

    const leftWallShape = new CANNON.Box(new CANNON.Vec3(0.25, 5, 15));
    const leftWallBody = new CANNON.Body({ mass: 0, material: world.theatreMaterial });
    leftWallBody.addShape(leftWallShape);
    leftWallBody.position.set(-15, 4, 0);
    world.addBody(leftWallBody);

    const rightWall = new THREE.Mesh(
        new THREE.BoxGeometry(0.5, 10, 30),
        wallMaterial
    );
    rightWall.position.set(15, 4, 0);
    scene.add(rightWall);

    const rightWallShape = new CANNON.Box(new CANNON.Vec3(0.25, 5, 15));
    const rightWallBody = new CANNON.Body({ mass: 0, material: world.theatreMaterial });
    rightWallBody.addShape(rightWallShape);
    rightWallBody.position.set(15, 4, 0);
    world.addBody(rightWallBody);

    // Screen wall
    const screenWallMaterial = new THREE.MeshStandardMaterial({
        color: 0x111111,
        emissive: 0x222244,
        emissiveIntensity: 0.5
    });
    const screenWall = new THREE.Mesh(
        new THREE.BoxGeometry(20, 10, 0.5),
        screenWallMaterial
    );
    screenWall.position.set(0, 4, -15);
    scene.add(screenWall);

    const screenWallShape = new CANNON.Box(new CANNON.Vec3(10, 5, 0.25));
    const screenWallBody = new CANNON.Body({ mass: 0, material: world.theatreMaterial });
    screenWallBody.addShape(screenWallShape);
    screenWallBody.position.set(0, 4, -15);
    world.addBody(screenWallBody);
}

function createTheaterSeats(scene, world) {
    const seatGeometry = new THREE.BoxGeometry(0.8, 0.8, 0.8);
    const seatMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x990000,
        roughness: 0.7 
    });
    
    const backrestGeometry = new THREE.BoxGeometry(0.8, 0.8, 0.2);
    const backrestMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x880000,
        roughness: 0.7 
    });

    // Create rows of seats
    for (let row = 0; row < 8; row++) {
        const rowZ = -12 + row * 2.5;
        const rowY = row * 0.3; // Slightly higher for each row (stadium seating)
        
        for (let col = -6; col <= 6; col += 2) {
            // Create seat
            const seat = new THREE.Group();
            
            const seatCushion = new THREE.Mesh(seatGeometry, seatMaterial);
            seatCushion.position.y = rowY;
            seatCushion.castShadow = true;
            seatCushion.receiveShadow = true;
            seat.add(seatCushion);
            
            const backrest = new THREE.Mesh(backrestGeometry, backrestMaterial);
            backrest.position.set(0, rowY + 0.7, 0.5);
            backrest.castShadow = true;
            backrest.receiveShadow = true;
            seat.add(backrest);
            
            seat.position.set(col * 1.2, 0, rowZ);
            scene.add(seat);
            
            // Seat physics body
            const seatShape = new CANNON.Box(new CANNON.Vec3(0.4, 0.4, 0.4));
            const backrestShape = new CANNON.Box(new CANNON.Vec3(0.4, 0.4, 0.1));
            
            const seatBody = new CANNON.Body({ mass: 0, material: world.theatreMaterial });
            seatBody.addShape(seatShape, new CANNON.Vec3(0, rowY, 0));
            seatBody.addShape(backrestShape, new CANNON.Vec3(0, rowY + 0.7, 0.5));
            seatBody.position.set(col * 1.2, 0, rowZ);
            world.addBody(seatBody);
            
            // Add person to the seat (except the first few rows as they're in front of player)
            if (row > 1 && Math.random() > 0.2) { // 80% chance of seat being occupied
                import('./audience.js').then(module => {
                    module.createAudienceMember(scene, col * 1.2, rowY + 0.8, rowZ);
                });
            }
        }
    }
}