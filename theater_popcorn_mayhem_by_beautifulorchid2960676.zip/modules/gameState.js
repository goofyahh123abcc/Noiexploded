export const gameState = {
    popcornCount: 50,
    suspicionLevel: 0,
    isGameOver: false, 
    isPoliceComing: false,
    throwPower: 0,
    popcorns: [],
    audienceMembers: [],
    personVariations: 20,
    assetsLoaded: true,
    camera: null,
    scene: null,
    world: null,
    policeGuard: null,
    popcornBeingHeld: false,
    throwInterval: null
};