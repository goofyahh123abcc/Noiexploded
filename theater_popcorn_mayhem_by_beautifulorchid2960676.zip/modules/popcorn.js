import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { gameState } from './gameState.js';
import { increaseSuspicion } from './suspicion.js';
import { updatePopcornCounter } from './ui.js';

export function createPopcornContainer(camera) {
    const container = new THREE.Group();
    
    // Container
    const containerGeometry = new THREE.CylinderGeometry(0.3, 0.2, 0.5, 16);
    const containerMaterial = new THREE.MeshStandardMaterial({
        color: 0xdd0000,
        roughness: 0.9
    });
    const containerMesh = new THREE.Mesh(containerGeometry, containerMaterial);
    containerMesh.position.y = 0.25;
    container.add(containerMesh);
    
    // Popcorn pile on top
    const popcornGeometry = new THREE.SphereGeometry(0.04, 8, 8);
    const popcornMaterial = new THREE.MeshStandardMaterial({
        color: 0xffffdd,
        roughness: 0.6
    });
    
    // Add multiple popcorn pieces
    for (let i = 0; i < 20; i++) {
        const popcorn = new THREE.Mesh(popcornGeometry, popcornMaterial);
        const angle = Math.random() * Math.PI * 2;
        const radius = Math.random() * 0.2;
        popcorn.position.x = Math.cos(angle) * radius;
        popcorn.position.z = Math.sin(angle) * radius;
        popcorn.position.y = 0.5 + Math.random() * 0.1;
        popcorn.rotation.set(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );
        popcorn.scale.set(
            0.8 + Math.random() * 0.4,
            0.8 + Math.random() * 0.4,
            0.8 + Math.random() * 0.4
        );
        container.add(popcorn);
    }
    
    // Position container in the bottom right of the screen
    container.position.set(0.4, -0.4, -0.7);
    
    // Add container to camera
    camera.add(container);
    
    return container;
}

export function createPopcorn(scene, world, position, velocity, spin) {
    // Create a detailed, irregular popcorn shape
    const popcornGroup = new THREE.Group();
    
    // Main popcorn body
    const coreGeometry = new THREE.SphereGeometry(0.05, 8, 8);
    const popcornMaterial = new THREE.MeshStandardMaterial({
        color: 0xffffee,
        roughness: 0.7
    });
    const core = new THREE.Mesh(coreGeometry, popcornMaterial);
    popcornGroup.add(core);
    
    // Add irregular "flakes" to make it look more realistic
    const flakeCount = 3 + Math.floor(Math.random() * 3);
    for (let i = 0; i < flakeCount; i++) {
        const flakeGeometry = new THREE.SphereGeometry(0.03 + Math.random() * 0.02, 6, 6);
        const flake = new THREE.Mesh(flakeGeometry, popcornMaterial);
        
        // Position flakes around the core at random angles
        const angle1 = Math.random() * Math.PI * 2;
        const angle2 = Math.random() * Math.PI * 2;
        const radius = 0.04 + Math.random() * 0.02;
        
        flake.position.x = Math.cos(angle1) * Math.sin(angle2) * radius;
        flake.position.y = Math.sin(angle1) * Math.sin(angle2) * radius;
        flake.position.z = Math.cos(angle2) * radius;
        
        popcornGroup.add(flake);
    }
    
    // Add popcorn to scene
    popcornGroup.position.copy(position);
    scene.add(popcornGroup);
    
    // Physics body for popcorn
    const popcornShape = new CANNON.Sphere(0.06);
    const popcornBody = new CANNON.Body({
        mass: 0.01, // Very light
        material: world.physicsMaterial,
        linearDamping: 0.3,
        angularDamping: 0.3,
    });
    popcornBody.addShape(popcornShape);
    popcornBody.position.copy(position);
    popcornBody.velocity.copy(velocity);
    
    // Add random spin
    popcornBody.angularVelocity.set(
        spin.x + (Math.random() - 0.5) * 5,
        spin.y + (Math.random() - 0.5) * 5,
        spin.z + (Math.random() - 0.5) * 5
    );
    
    world.addBody(popcornBody);
    
    // Add to game state
    const popcorn = {
        mesh: popcornGroup,
        body: popcornBody,
        timeCreated: Date.now(),
        thrownByPlayer: true
    };
    
    gameState.popcorns.push(popcorn);
    
    return popcorn;
}

export function throwPopcorn(scene, world, camera, power = 1) {
    if (gameState.popcornCount <= 0 || gameState.isGameOver) return;
    
    gameState.popcornCount--;
    updatePopcornCounter();
    
    // Calculate throw direction and strength
    const throwDirection = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
    
    // Create popcorn at position slightly in front of camera
    const popcornPos = new THREE.Vector3();
    popcornPos.copy(camera.position).add(throwDirection.clone().multiplyScalar(0.5));
    
    // Add some randomness to throw direction
    throwDirection.x += (Math.random() - 0.5) * 0.1;
    throwDirection.y += (Math.random() - 0.5) * 0.1;
    throwDirection.z += (Math.random() - 0.5) * 0.1;
    
    // Convert THREE vector to CANNON vector
    const velocity = new CANNON.Vec3(
        throwDirection.x * power * 10,
        throwDirection.y * power * 10,
        throwDirection.z * power * 10
    );
    
    // Random spin
    const spin = new CANNON.Vec3(
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 10
    );
    
    createPopcorn(scene, world, popcornPos, velocity, spin);
    
    // Increase suspicion
    increaseSuspicion(power * 2);
}