import * as THREE from 'three';
import { gameState } from './gameState.js';
import { createPopcorn } from './popcorn.js';

export function createAudienceMember(scene, x, y, z) {
    // Create a basic person shape
    const personVariation = Math.floor(Math.random() * gameState.personVariations);
    const personHeight = 0.9 + Math.random() * 0.3;
    
    const person = new THREE.Group();
    
    // Head
    const headGeometry = new THREE.SphereGeometry(0.2, 16, 16);
    const skinTone = new THREE.Color(0.8 + Math.random() * 0.2, 0.5 + Math.random() * 0.3, 0.4 + Math.random() * 0.3);
    const headMaterial = new THREE.MeshStandardMaterial({ 
        color: skinTone,
        roughness: 0.7
    });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = personHeight;
    head.castShadow = true;
    person.add(head);
    
    // Body
    const bodyGeometry = new THREE.CapsuleGeometry(0.25, personHeight - 0.3, 8, 8);
    
    // Clothing color - varied based on personVariation
    const clothingColors = [
        0x0000ff, 0xff0000, 0x00ff00, 0xffff00, 0xff00ff,
        0x00ffff, 0x880000, 0x008800, 0x000088, 0x888800,
        0x880088, 0x008888, 0x333333, 0x666666, 0x999999,
        0x336699, 0x996633, 0x339966, 0x663399, 0x993366
    ];
    
    const bodyMaterial = new THREE.MeshStandardMaterial({ 
        color: clothingColors[personVariation],
        roughness: 0.9 
    });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.position.y = personHeight / 2;
    body.castShadow = true;
    person.add(body);
    
    // Add hair (different styles based on variation)
    if (personVariation % 4 === 0) {
        // Short hair
        const hairGeometry = new THREE.SphereGeometry(0.21, 16, 16);
        const hairMaterial = new THREE.MeshStandardMaterial({
            color: 0x111111 + personVariation * 0x0a0a0a,
            roughness: 0.9
        });
        const hair = new THREE.Mesh(hairGeometry, hairMaterial);
        hair.position.y = personHeight + 0.01;
        hair.scale.y = 0.7;
        person.add(hair);
    } else if (personVariation % 4 === 1) {
        // Long hair
        const hairGeometry = new THREE.CylinderGeometry(0.21, 0.18, 0.5, 16);
        const hairMaterial = new THREE.MeshStandardMaterial({
            color: 0x331100 + personVariation * 0x0a0a0a,
            roughness: 0.9
        });
        const hair = new THREE.Mesh(hairGeometry, hairMaterial);
        hair.position.y = personHeight + 0.05;
        person.add(hair);
    } else if (personVariation % 4 === 2) {
        // Hat
        const hatGeometry = new THREE.CylinderGeometry(0.25, 0.25, 0.15, 16);
        const hatMaterial = new THREE.MeshStandardMaterial({
            color: 0x444444 + personVariation * 0x040404,
            roughness: 0.7
        });
        const hat = new THREE.Mesh(hatGeometry, hatMaterial);
        hat.position.y = personHeight + 0.15;
        person.add(hat);
    }
    // else no hair/bald
    
    // Add random rotation for head (looking around)
    const initialRotation = Math.random() * Math.PI * 0.3 - Math.PI * 0.15;
    head.rotation.y = initialRotation;
    
    // Position the person and add to scene
    person.position.set(x, y, z);
    scene.add(person);
    
    // Person has a chance to throw popcorn randomly
    const throwsPopcorn = Math.random() > 0.7; // 30% chance
    
    // Add to audience members array
    gameState.audienceMembers.push({
        mesh: person,
        throwsPopcorn,
        head,
        initialRotation,
        nextThrowTime: throwsPopcorn ? Math.random() * 5000 : null,
    });
}

export function updateAudienceThrows(scene, world) {
    const now = Date.now();
    
    gameState.audienceMembers.forEach(member => {
        if (member.throwsPopcorn && member.nextThrowTime && now >= member.nextThrowTime) {
            // Turn head towards target before throwing
            if (member.head) {
                // Look in a random direction
                member.head.rotation.y = member.initialRotation + (Math.random() - 0.5) * Math.PI;
            }
            
            // Throw after a short delay
            setTimeout(() => {
                if (!gameState.isGameOver) {
                    audienceThrowPopcorn(scene, world, member);
                }
            }, 500);
        }
    });
}

function audienceThrowPopcorn(scene, world, member) {
    // Determine throw target (random audience member or player)
    const targetIndex = Math.floor(Math.random() * (gameState.audienceMembers.length + 1));
    let targetPosition;
    
    if (targetIndex === gameState.audienceMembers.length) {
        // Target the player
        targetPosition = gameState.camera.position.clone();
    } else {
        // Target another audience member
        targetPosition = gameState.audienceMembers[targetIndex].mesh.position.clone();
        targetPosition.y += 1.0; // Aim for head
    }
    
    // Create popcorn at thrower's position
    const throwPosition = member.mesh.position.clone();
    throwPosition.y += 1.1; // from hand position
    
    // Calculate throw direction
    const throwDirection = new THREE.Vector3().subVectors(targetPosition, throwPosition).normalize();
    
    // Add some randomness
    throwDirection.x += (Math.random() - 0.5) * 0.2;
    throwDirection.y += (Math.random() - 0.5) * 0.1;
    throwDirection.z += (Math.random() - 0.5) * 0.2;
    
    // Calculate throw power based on distance
    const distance = throwPosition.distanceTo(targetPosition);
    const power = 0.5 + (distance / 10) + (Math.random() * 0.3);
    
    // Convert THREE vector to CANNON vector
    const velocity = new CANNON.Vec3(
        throwDirection.x * power * 10,
        throwDirection.y * power * 10,
        throwDirection.z * power * 10
    );
    
    // Random spin
    const spin = new CANNON.Vec3(
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 10
    );
    
    const popcorn = createPopcorn(scene, world, throwPosition, velocity, spin);
    popcorn.thrownByPlayer = false;
    
    // Set next throw time
    member.nextThrowTime = Date.now() + 3000 + Math.random() * 7000;
    
    // Turn head back to normal after throwing
    setTimeout(() => {
        if (member.head) {
            member.head.rotation.y = member.initialRotation;
        }
    }, 1000);
}