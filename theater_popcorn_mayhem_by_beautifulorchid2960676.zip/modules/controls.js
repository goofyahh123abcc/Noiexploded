import { gameState } from './gameState.js';
import { throwPopcorn } from './popcorn.js';

export function setupControls(camera, renderer, startThrowChargeFunc, releaseThrowFunc, restartGameFunc) {
    const throwButton = document.getElementById('throw-button');
    
    // Throw button - touch events
    throwButton.addEventListener('touchstart', (e) => {
        e.preventDefault();
        startThrowChargeFunc();
    });
    
    throwButton.addEventListener('touchend', (e) => {
        e.preventDefault();
        releaseThrowFunc();
    });
    
    // Throw button - mouse events
    throwButton.addEventListener('mousedown', startThrowChargeFunc);
    throwButton.addEventListener('mouseup', releaseThrowFunc);
    
    // Restart button
    document.getElementById('restart-button').addEventListener('click', restartGameFunc);
    
    // Rotate camera with touch drag
    let touchStartX = 0;
    let touchStartY = 0;
    
    renderer.domElement.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
            touchStartX = e.touches[0].clientX;
            touchStartY = e.touches[0].clientY;
        }
    });
    
    renderer.domElement.addEventListener('touchmove', (e) => {
        if (e.touches.length === 1) {
            // Calculate delta
            const touchEndX = e.touches[0].clientX;
            const touchEndY = e.touches[0].clientY;
            const deltaX = touchEndX - touchStartX;
            const deltaY = touchEndY - touchStartY;
            
            // Rotate camera
            camera.rotation.y -= deltaX * 0.01;
            camera.rotation.x -= deltaY * 0.01;
            
            // Limit vertical rotation
            camera.rotation.x = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, camera.rotation.x));
            
            // Update start position
            touchStartX = touchEndX;
            touchStartY = touchEndY;
        }
    });
    
    // Mouse look (on desktop)
    let isMouseDown = false;
    let lastMouseX = 0;
    let lastMouseY = 0;
    
    renderer.domElement.addEventListener('mousedown', (e) => {
        if (e.button === 0) { // Left mouse button
            isMouseDown = true;
            lastMouseX = e.clientX;
            lastMouseY = e.clientY;
        }
    });
    
    renderer.domElement.addEventListener('mouseup', () => {
        isMouseDown = false;
    });
    
    renderer.domElement.addEventListener('mousemove', (e) => {
        if (isMouseDown) {
            // Calculate delta
            const deltaX = e.clientX - lastMouseX;
            const deltaY = e.clientY - lastMouseY;
            
            // Rotate camera
            camera.rotation.y -= deltaX * 0.005;
            camera.rotation.x -= deltaY * 0.005;
            
            // Limit vertical rotation
            camera.rotation.x = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, camera.rotation.x));
            
            // Update last position
            lastMouseX = e.clientX;
            lastMouseY = e.clientY;
        }
    });
    
    // Handle window resize
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
}

export function startThrowCharge() {
    if (gameState.isGameOver || gameState.popcornCount <= 0) return;
    
    gameState.popcornBeingHeld = true;
    gameState.throwPower = 0;
    
    // Start charging
    document.getElementById('throw-button').classList.add('active');
    
    // Start increasing throw power
    gameState.throwInterval = setInterval(() => {
        if (gameState.throwPower < 1) {
            gameState.throwPower += 0.05;
        }
    }, 100);
}

export function releaseThrow() {
    if (!gameState.popcornBeingHeld) return;
    
    // Clear throw interval
    clearInterval(gameState.throwInterval);
    
    // Throw with current power
    throwPopcorn(gameState.scene, gameState.world, gameState.camera, gameState.throwPower);
    
    // Reset state
    gameState.popcornBeingHeld = false;
    gameState.throwPower = 0;
    document.getElementById('throw-button').classList.remove('active');
}