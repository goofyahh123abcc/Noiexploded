import * as THREE from 'three';
import { gameState } from './gameState.js';
import { gameOver } from './ui.js';

export function createPoliceGuard(scene) {
    const policeOfficer = new THREE.Group();
    
    // Head
    const headGeometry = new THREE.SphereGeometry(0.2, 16, 16);
    const headMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xe0b080,
        roughness: 0.7
    });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = 1.7;
    head.castShadow = true;
    policeOfficer.add(head);
    
    // Body
    const bodyGeometry = new THREE.CapsuleGeometry(0.3, 1.0, 8, 8);
    const bodyMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x000066,
        roughness: 0.9 
    });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.position.y = 1.0;
    body.castShadow = true;
    policeOfficer.add(body);
    
    // Hat
    const hatGeometry = new THREE.CylinderGeometry(0.22, 0.25, 0.15, 16);
    const hatMaterial = new THREE.MeshStandardMaterial({
        color: 0x000033,
        roughness: 0.7
    });
    const hat = new THREE.Mesh(hatGeometry, hatMaterial);
    hat.position.y = 1.9;
    policeOfficer.add(hat);
    
    // Badge
    const badgeGeometry = new THREE.CircleGeometry(0.07, 16);
    const badgeMaterial = new THREE.MeshStandardMaterial({
        color: 0xffcc00,
        metalness: 0.7,
        roughness: 0.3
    });
    const badge = new THREE.Mesh(badgeGeometry, badgeMaterial);
    badge.position.set(0.3, 1.2, 0.28);
    badge.rotation.y = Math.PI / 2;
    policeOfficer.add(badge);
    
    // Position the police officer off screen initially
    policeOfficer.position.set(0, 0, 20); // Behind the player
    scene.add(policeOfficer);
    
    gameState.policeGuard = {
        mesh: policeOfficer,
        isPatrolling: false,
        head,
        targetPosition: new THREE.Vector3()
    };
}

export function updatePolice(camera, deltaTime) {
    if (!gameState.policeGuard.isPatrolling) return;
    
    // Update target to follow player
    gameState.policeGuard.targetPosition.copy(camera.position);
    
    // Move towards player
    const policeSpeed = 0.04;
    const direction = new THREE.Vector3().subVectors(
        gameState.policeGuard.targetPosition,
        gameState.policeGuard.mesh.position
    ).normalize();
    
    gameState.policeGuard.mesh.position.add(
        direction.multiplyScalar(policeSpeed * deltaTime)
    );
    
    // Look at player
    gameState.policeGuard.mesh.lookAt(camera.position);
    
    // Have the head track the player more precisely
    const headDirection = new THREE.Vector3().subVectors(
        camera.position,
        gameState.policeGuard.mesh.position
    ).normalize();
    
    // Convert to euler angles for the head
    const headRotation = new THREE.Euler().setFromQuaternion(
        new THREE.Quaternion().setFromUnitVectors(
            new THREE.Vector3(0, 0, 1),
            headDirection
        )
    );
    
    gameState.policeGuard.head.rotation.y = headRotation.y;
}

export function triggerPolice() {
    gameState.isPoliceComing = true;
    document.getElementById('police-warning').classList.remove('hidden');
    
    // Position police at back of theater
    gameState.policeGuard.mesh.position.set(0, 0, 14);
    gameState.policeGuard.targetPosition.copy(gameState.camera.position);
    gameState.policeGuard.isPatrolling = true;
    
    // Set police to come to the player's position
    setTimeout(() => {
        if (!gameState.isGameOver) {
            gameOver("You were caught by theater security! Too much popcorn throwing has consequences.");
        }
    }, 6000);
}