import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { gameState } from './modules/gameState.js';
import { initScene, createTheaterLighting, createTheater } from './modules/scene.js';
import { initPhysics } from './modules/physics.js';
import { setupControls, startThrowCharge, releaseThrow } from './modules/controls.js';
import { createPopcornContainer } from './modules/popcorn.js';
import { updatePolice } from './modules/police.js';
import { updateAudienceThrows } from './modules/audience.js';
import { decreaseSuspicion } from './modules/suspicion.js';
import { updateUIAfterRestart, updatePopcornCounter } from './modules/ui.js';

const gameContainer = document.getElementById('game-container');
let renderer;

// Initialize the game
async function main() {
    // Initialize game state
    gameState.scene = initScene();
    gameState.world = initPhysics();
    
    // Renderer
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    gameContainer.appendChild(renderer.domElement);

    // Camera
    gameState.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100); 
    gameState.camera.position.set(0, 1.6, 8); 
    gameState.camera.lookAt(0, 1, 0); 

    // Setup scene
    createTheaterLighting(gameState.scene); 
    createTheater(gameState.scene, gameState.world); 
    createPopcornContainer(gameState.camera); 

    // Setup controls - pass imported functions
    setupControls(gameState.camera, renderer, startThrowCharge, releaseThrow, restartGame);

    // Initial UI update
    updatePopcornCounter();
    decreaseSuspicion(); 

    // Start game loop
    animate();
}

main().catch(err => console.error("Error in main execution:", err));

function restartGame() {
    // Simple restart: reload the page
    window.location.reload();
    // For a soft reset, you'd call updateUIAfterRestart() and reset other game logic.
}

const clock = new THREE.Clock();

function animate() {
    gameState.animationFrameId = requestAnimationFrame(animate);
    const deltaTime = clock.getDelta();

    if (gameState.isGameOver) return;

    // Update physics world
    gameState.world.step(1 / 60, deltaTime, 3); 

    // Update popcorn physics and remove old popcorn
    for (let i = gameState.popcorns.length - 1; i >= 0; i--) {
        const popcorn = gameState.popcorns[i];
        popcorn.mesh.position.copy(popcorn.body.position);
        popcorn.mesh.quaternion.copy(popcorn.body.quaternion);

        // Remove popcorn after some time (e.g., 10 seconds)
        if (Date.now() - popcorn.timeCreated > 10000) {
            gameState.world.removeBody(popcorn.body);
            gameState.scene.remove(popcorn.mesh);
            gameState.popcorns.splice(i, 1);
        }
    }

    // Update police guard
    if (gameState.policeGuard && gameState.isPoliceComing) {
        updatePolice(gameState.camera, deltaTime * 1000); 
    }

    // Update audience behavior (e.g., throwing popcorn)
    updateAudienceThrows(gameState.scene, gameState.world);

    // Gradually decrease suspicion
    decreaseSuspicion();

    // Render scene
    renderer.render(gameState.scene, gameState.camera);
}

// Handle window resize for renderer and camera
window.addEventListener('resize', () => {
    if (gameState.camera && renderer) {
        gameState.camera.aspect = window.innerWidth / window.innerHeight;
        gameState.camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    }
});